#include "Ant.h"
#include "Map.h" //
using namespace std;

Ant::Ant():Organism(TYPE_ANT,0){}

int Ant::move(){
	return rand()%4 + 1;
}

int Ant::breed(){
	if(getMoveCount() % 4 == 0 && getMoveCount()!=0 ) return 1;
	else return 0;
}
