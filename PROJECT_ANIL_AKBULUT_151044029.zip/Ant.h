#ifndef ANT_H
#define ANT_H
#include "Organism.h"

#include <iostream>

class MAP;//

class Ant:public Organism{
public:
	Ant();
	int move();
	int breed();
};

#endif