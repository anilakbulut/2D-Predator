#include "Doodlebug.h"
#include "Map.h"//
#include <cstdlib>
Doodlebug::Doodlebug():Organism(TYPE_DOODLE,0){}
int Doodlebug::move(){
	return rand()%4+1;	
}
int Doodlebug::breed(){
	if(getMoveCount() % 4 == 0 && getMoveCount()!=0 ) return 1;
	else return 0;
}