#ifndef DOODLEBUG_H
#define DOODLEBUG_H
#include "Organism.h"

class MAP; // 

class Doodlebug:public Organism{
public:
	Doodlebug();
	int move();
	int breed();
};



#endif