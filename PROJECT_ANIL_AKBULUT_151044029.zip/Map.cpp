#include "Map.h"
#include "Organism.h"
#include "Ant.h"
#include "Doodlebug.h"

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

MAP::MAP(){
	srand(time(NULL));
	int i=0,j=0;
	int x,y;
	for(i=0;i<MAP_X;i++)
		for(j=0;j<MAP_Y;j++){
			map[i][j] = NULL;
		}
	i=0;
	while(i<COUNT_ANT){
		do{
			random(x,y);
		}while(map[x][y]!=NULL);
		map[x][y] = new Ant();
		i++;
	}
	j=0;
	while(j<COUNT_DOODLEBUG){
		do{
			random(x,y);
		}while(map[x][y]!=NULL);
		map[x][y] = new Doodlebug();
		j++;
	}	
}
void MAP::random(int &x,int &y){
	x = rand()%MAP_X;
	y = rand()%MAP_Y;
}
void MAP::print_map(){
	int i,j;
	for(i=0;i<MAP_X;i++){
		for(j=0;j<MAP_Y;j++){
			if(map[i][j] == NULL) cout << "- ";
			else if(map[i][j]->getType() == TYPE_ANT) cout << TYPE_ANT << " ";
			else if(map[i][j]->getType() == TYPE_DOODLE) cout << TYPE_DOODLE << " ";
		}
		cout << endl;
	}
}
void MAP::breeded(){
	int i,j;
	int flag=0;
	int temp;
	for(i=0;i<MAP_X;i++){
		for(j=0;j<MAP_Y;j++){
			flag = 0;
			if(map[i][j]!=NULL && map[i][j]->getType() == TYPE_ANT && map[i][j]->breed() == 1){
				while(flag==0){
					temp = map[i][j]->move();
					if(temp == 1){
						if(i>=0 && i<MAP_X && j>0 && j<MAP_Y && map[i][j-1]==NULL){ //left breed
							flag = 1;
							map[i][j-1] = new Ant();	
						}else while(temp!=1){
							temp = map[i][j]->move();
						}
					}
					if(temp == 2 ){
						if(i>=0 && i<MAP_X && j>=0 && j<MAP_Y-1 && map[i][j+1]==NULL){ // right breed
							map[i][j+1] = new Ant();
							flag = 1;		
						}
						else while(temp!=2){
							temp = map[i][j]->move();
						}
					}
					if(temp == 3){
						if(i>=0 && i<MAP_X-1 && j>=0 && j<MAP_Y && map[i+1][j]==NULL){	// down breed	
							flag = 1;
							map[i+1][j] = new Ant();
						}
						else while(temp!=3){
							temp = map[i+1][j]->move();
						}
					}
					if(temp == 4){
						if(i>0 && i<MAP_X && j>=0 && j<MAP_Y && map[i-1][j]==NULL){		
							flag = 1;
							map[i-1][j] = new Ant();
						}
						else while(temp!=4){
							temp = map[i-1][j]->move();
						}
					}
					else flag = 1;
				}
			}
		}
	}
	for(i=0;i<MAP_X;i++){
		for(j=0;j<MAP_Y;j++){
			flag = 0;
			if(map[i][j]!=NULL && map[i][j]->getType() == TYPE_DOODLE && map[i][j]->breed() == 1){
				while(flag==0){
					temp = map[i][j]->move();
					if(temp == 1){
						if(i>=0 && i<MAP_X && j>0 && j<MAP_Y && map[i][j-1]==NULL){ //left breed
							flag = 1;
							map[i][j-1] = new Doodlebug();
						}else while(temp!=1){
							temp = map[i][j]->move();
						}
					}
					if(temp == 2 ){
						if(i>=0 && i<MAP_X && j>=0 && j<MAP_Y-1 && map[i][j+1]==NULL){ // right breed
							map[i][j+1] = new Doodlebug();
							flag = 1;
						}
						else while(temp!=2){
							temp = map[i][j]->move();
						}
					}
					if(temp == 3){
						if(i>=0 && i<MAP_X-1 && j>=0 && j<MAP_Y && map[i+1][j]==NULL){	// down breed	
							flag = 1;
							map[i+1][j] = new Doodlebug();
						}
						else while(temp!=3){
							temp = map[i+1][j]->move();
						}
					}
					if(temp == 4){
						if(i>0 && i<MAP_X && j>=0 && j<MAP_Y && map[i-1][j]==NULL){		
							flag = 1;
							map[i-1][j] = new Doodlebug();
						}
						else while(temp!=4){
							temp = map[i-1][j]->move();
						}
					}
					else flag = 1;
				}
			}
		}
	}
}
void MAP::moved(){
	int temp;
	int flag=0;
	for(int i=0;i<MAP_X;i++)
		for(int j=0;j<MAP_Y;j++){
			flag=0;
			if(map[i][j]!=NULL && map[i][j]->getType() == TYPE_ANT){
				while(flag==0){
					temp = map[i][j]->move();
					if(temp == 1 ){ // sola gitme j-1
						if(i>=0 && i<MAP_X && j>0 && j<MAP_Y && map[i][j-1]==NULL){	
							flag = 1;
							map[i][j-1] = new Ant();
							map[i][j-1]->plus_move_count(map[i][j]->getMoveCount());
							delete map[i][j];
							map[i][j]=NULL;
							j++;							
						}
						else while(temp!=1){
							temp = map[i][j]->move();
						}
					}
					if(temp == 2 ){ // saga gitme j+1
						if(i>=0 && i<MAP_X && j>=0 && j<MAP_Y-1 && map[i][j+1]==NULL){							
							flag = 1;
							map[i][j+1] = new Ant();
							map[i][j+1]->plus_move_count(map[i][j]->getMoveCount());
							delete map[i][j];
							map[i][j]=NULL;
							j++;
						}
						else while(temp!=2){
							temp = map[i][j]->move();
						}
					}
					if(temp == 3){ // asagi i+1
						if(i>=0 && i<MAP_X-1 && j>=0 && j<MAP_Y && map[i+1][j]==NULL){				
							flag = 1;
							map[i+1][j] = new Ant();
							map[i+1][j]->plus_move_count(map[i][j]->getMoveCount());
							delete map[i][j];
							map[i][j] = 0;
							j++;
						}
						else while(temp!=3){
							temp = map[i][j]->move();
						}
					}
					if(temp == 4){ // yukari i-1
						if(i>0 && i<MAP_X && j>=0 && j<MAP_Y && map[i-1][j]==NULL){		
							flag = 1;
							map[i-1][j] = new Ant();
							map[i-1][j]->plus_move_count(map[i][j]->getMoveCount());
							delete map[i][j];
							map[i][j] = 0;
							j++;
						}
						else while(temp!=4){
							temp = map[i][j]->move();
						}
					}
					else flag = 1;
				}
				
			}
		}
	flag =0;
	for(int i=0;i<MAP_X;i++)
		for(int j=0;j<MAP_Y;j++){
			flag=0;
			if(map[i][j]!=NULL && map[i][j]->getType() == TYPE_DOODLE){
				while(flag==0){
					temp = map[i][j]->move();
					if(temp == 1 ){ // sola gitme j-1
						if(i>=0 && i<MAP_X && j>0 && j<MAP_Y && map[i][j-1]==NULL){	
							flag = 1;
							map[i][j-1] = new Doodlebug();
							map[i][j-1]->plus_move_count(map[i][j]->getMoveCount());
							delete map[i][j];
							map[i][j]=NULL;
							j++;
						}
						else while(temp!=1){
							temp = map[i][j]->move();
						}
					}
					if(temp == 2 ){ // saga gitme j+1
						if(i>=0 && i<MAP_X && j>=0 && j<MAP_Y-1 && map[i][j+1]==NULL){
							flag = 1;
							map[i][j+1] = new Doodlebug();
							map[i][j+1]->plus_move_count(map[i][j]->getMoveCount());						
							delete map[i][j];
							map[i][j]=NULL;
							j++;
						}
						else while(temp!=2){
							temp = map[i][j]->move();
						}
					}
					if(temp == 3){ // asagi i+1
						if(i>=0 && i<MAP_X-1 && j>=0 && j<MAP_Y && map[i+1][j]==NULL){	
							flag = 1;
							map[i+1][j] = new Doodlebug();
							map[i+1][j]->plus_move_count(map[i][j]->getMoveCount());			
							delete map[i][j];
							map[i][j] = 0;
							j++;
						}
						else while(temp!=3){
							temp = map[i][j]->move();
						}
					}
					if(temp == 4){ // yukari i-1
						if(i>0 && i<MAP_X && j>=0 && j<MAP_Y && map[i-1][j]==NULL){	
							flag = 1;
							map[i-1][j] = new Doodlebug();
							map[i-1][j]->plus_move_count(map[i][j]->getMoveCount());	
							delete map[i][j];
							map[i][j] = 0;
							j++;
						}
						else while(temp!=4){
							temp = map[i][j]->move();
						}
					}
					else flag = 1;
				}
				
			}
		}
}
