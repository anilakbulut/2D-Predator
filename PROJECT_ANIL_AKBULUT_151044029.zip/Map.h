#ifndef MAP_H
#define MAP_H

class Organism;
class Ant;
class Doodlebug;

const int MAP_X=20;
const int MAP_Y=20;
const int TYPE_ANT=1;
const int TYPE_DOODLE=3;
const int COUNT_ANT=20;
const int COUNT_DOODLEBUG=5;

class MAP{
public:
	friend class Organism;
	friend class Ant;
	friend class Doodlebug;
	MAP();
	void random(int &x,int &y);
	void print_map();
	void moved();
	void breeded();
private:
	Organism *map[MAP_X][MAP_Y];
};



#endif