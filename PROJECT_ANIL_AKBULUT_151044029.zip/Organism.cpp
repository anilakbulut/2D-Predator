#include "Organism.h"
#include "Map.h" //

Organism::Organism(int newtype,int new_move_count):type(newtype),move_count(new_move_count){}
int Organism::getType(){return type;}
void Organism::plus_move_count(int add){
	move_count = move_count + add;
	move_count++;
;}
int Organism::getMoveCount(){return move_count;}
void Organism::reset_breed_count(){
	move_count=0;
}