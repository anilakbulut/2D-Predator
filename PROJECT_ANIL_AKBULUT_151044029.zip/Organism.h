#ifndef ORGANISM_H
#define ORGANISM_H
class MAP; // 

class Organism{
public:
	Organism(int newtype,int new_move_count);
	int getType();
	int getMoveCount();
	void plus_move_count(int add);
	void reset_breed_count();
	virtual int move()=0;
	virtual int breed()=0;
private:
	int type;
	int move_count;
};



#endif