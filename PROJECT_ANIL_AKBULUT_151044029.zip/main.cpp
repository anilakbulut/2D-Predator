#include <iostream>
#include "Map.h"

using namespace std;

int main(){
	MAP gamer;
	cout << endl;
	char input= 'x';
	while(input!='E' && input!='e'){
		cout << "Exit: 'E' or 'e' buttons" << endl;
		gamer.moved();
		cout << endl;
		gamer.breeded();
		gamer.print_map();
		cout << endl;
		cin >> input;
	}	
	return 1;
}